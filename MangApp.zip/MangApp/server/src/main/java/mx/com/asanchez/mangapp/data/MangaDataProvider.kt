package mx.com.asanchez.mangapp.data

import kotlinx.coroutines.Deferred
import mx.com.asanchez.mangapp.data.domain.Manga
import mx.com.asanchez.mangapp.data.domain.Provider
import mx.com.asanchez.mangapp.data.mangatown.MangaTownDataProvider
import mx.com.asanchez.mangapp.data.providers.MangaProvider
import javax.inject.Inject

class MangaDataProvider @Inject constructor(
    private val provider: Provider,
    private val mangaTownDataProvider: MangaTownDataProvider
) : MangaProvider {
    override fun fetchLatestMangas(page: Int): Deferred<Result<List<Manga>>> = when (provider) {
        Provider.MANGATOWN -> mangaTownDataProvider.fetchLatestMangas(page)
        else -> mangaTownDataProvider.fetchLatestMangas(page)
    }

    override fun fetchMangaDetails(nameLink: String): Deferred<Result<Manga>> = when (provider) {
        Provider.MANGATOWN -> mangaTownDataProvider.fetchMangaDetails(nameLink)
        else -> mangaTownDataProvider.fetchMangaDetails(nameLink)
    }
}