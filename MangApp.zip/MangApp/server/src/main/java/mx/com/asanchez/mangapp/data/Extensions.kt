package mx.com.asanchez.mangapp.data

import mx.com.asanchez.mangapp.data.domain.Manga
import mx.com.asanchez.mangapp.data.mangatown.Post

fun List<Post>.mapMangas(): List<Manga> = this.map {
    Manga(
        title = it.title,
        coverUrl = it.coverSrc,
        src = it.src,
        latestChapter = it.latestChapter,
        latestChapterSrc = it.latestChapterSrc
    )
}