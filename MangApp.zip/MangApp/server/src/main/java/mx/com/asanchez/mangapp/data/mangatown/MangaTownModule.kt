package mx.com.asanchez.mangapp.data.mangatown

import com.jakewharton.retrofit2.adapter.kotlin.coroutines.CoroutineCallAdapterFactory
import dagger.Module
import dagger.Provides
import mx.com.asanchez.mangapp.data.HTTP_CLIENT
import okhttp3.OkHttpClient
import pl.droidsonroids.jspoon.Jspoon
import pl.droidsonroids.retrofit2.JspoonConverterFactory
import retrofit2.Retrofit
import javax.inject.Named
import javax.inject.Singleton

@Module
class MangaTownModule {
    @Provides
    @Singleton
    fun mangaTownApi(@Named(MANGATOWN_RETROFIT) retrofit: Retrofit) = retrofit.create(MangaTownApi::class.java)

    @Provides
    @Named(MANGATOWN_RETROFIT)
    @Singleton
    fun retrofit(@Named(HTTP_CLIENT) okHttpClient: OkHttpClient) =
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(JspoonConverterFactory.create())
            .addCallAdapterFactory(CoroutineCallAdapterFactory.invoke())
            .build()

    @Provides
    @Named(MANGATOWN_JSPOON)
    @Singleton
    fun jspoon() = Jspoon.create()
}

const val BASE_URL = "http://m.mangatown.com/"
const val MANGATOWN_RETROFIT = "mangatown.retrofit"
const val MANGATOWN_JSPOON = "mangatown.jspoon"