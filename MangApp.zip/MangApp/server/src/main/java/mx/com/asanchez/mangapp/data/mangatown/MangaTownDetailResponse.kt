package mx.com.asanchez.mangapp.data.mangatown

import android.support.annotation.Keep
import pl.droidsonroids.jspoon.annotation.Selector

@Keep
class MangaTownDetailResponse {
    @Selector("div.title")
    var title: String = ""

    @Selector("img.detail-cover", attr = "src")
    var coverUrl: String = ""
}