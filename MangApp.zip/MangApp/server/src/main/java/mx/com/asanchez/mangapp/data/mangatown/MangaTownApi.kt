package mx.com.asanchez.mangapp.data.mangatown

import kotlinx.coroutines.Deferred
import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.Path

interface MangaTownApi {
    @GET("latest")
    fun getLatest() : Deferred<MangaTownLatestResponse>

    @GET("latest/{page}.html")
    fun getLatestPage(@Path("page") page: Int) : Deferred<MangaTownLatestResponse>

    @GET("manga/{nameLink}")
    fun getMangaDetails(@Path("nameLink") nameLink: String) : Deferred<MangaTownDetailResponse>
}