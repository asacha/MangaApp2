package mx.com.asanchez.mangapp.data.mangatown

import android.support.annotation.Keep
import pl.droidsonroids.jspoon.annotation.Selector

@Keep
class MangaTownLatestResponse {
    @Selector(".post-list > li")
    var postList: List<Post> = listOf()
}

@Keep
class Post {
    @Selector("div.post > a > div.post-info > p.title")
    var title: String = ""

    @Selector("div.post > a.manga-cover > img", attr = "src")
    var coverSrc: String = ""

    @Selector("div.post > a.manga-cover", attr = "href")
    var src: String = ""

    @Selector("div.post > a.read-btn")
    var latestChapter: String = ""

    @Selector("div.post > a.read-btn", attr = "href")
    var latestChapterSrc: String = ""
}