package mx.com.asanchez.mangapp.data

import android.support.annotation.Keep
import com.squareup.moshi.FromJson
import com.squareup.moshi.Json
import com.squareup.moshi.JsonQualifier
import com.squareup.moshi.ToJson

@Retention(AnnotationRetention.RUNTIME)
@JsonQualifier
annotation class JsonNameAsString

@Keep
data class JsonName(
    @Json(name = "name") val name: String
)

object JsonNameStringAdapter {
    @ToJson
    fun toJson(@JsonNameAsString name: String) = JsonName(name)

    @FromJson
    @JsonNameAsString
    fun fromJson(json: JsonName) = json.name
}

@Retention(AnnotationRetention.RUNTIME)
@JsonQualifier
annotation class NullIfEmpty

object NullIfEmptyStringAdapter {
    @ToJson
    fun toJson(@NullIfEmpty name: String?) = when {
        name.isNullOrEmpty() -> null
        else -> name
    }

    @FromJson
    @NullIfEmpty
    fun fromJson(json: String?) = when {
        json.isNullOrEmpty() -> null
        else -> json
    }
}