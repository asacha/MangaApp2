package mx.com.asanchez.mangapp.data.mangatown

import kotlinx.coroutines.Deferred
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import mx.com.asanchez.mangapp.data.providers.MangaTownProvider
import mx.com.asanchez.mangapp.data.Result
import mx.com.asanchez.mangapp.data.domain.Manga
import mx.com.asanchez.mangapp.data.mapMangas
import java.lang.Exception
import javax.inject.Inject

class MangaTownDataProvider @Inject constructor(
    private val mangaTownApi: MangaTownApi
) : MangaTownProvider {

    private val cachedMangas = mutableMapOf<Int, List<Manga>>()

    override fun fetchLatestMangas(page: Int): Deferred<Result<List<Manga>>> = GlobalScope.async {
        try {
            Result.Ok(mangaTownApi.getLatestPage(page).await().postList.mapMangas().run {
                cachedMangas[page] = this
                this
            })
        } catch (e: Exception) {
            Result.Err(e)
        }
    }

    override fun fetchMangaDetails(nameLink: String): Deferred<Result<Manga>> = GlobalScope.async {
        try {
            Result.Ok(mangaTownApi.getMangaDetails(nameLink).await().run {
                Manga(
                    title = this.title,
                    coverUrl = this.coverUrl,
                    latestChapterSrc = "",
                    latestChapter = "",
                    src = ""
                )
            })
        } catch (e: Exception) {
            Result.Err(e)
        }
    }
}