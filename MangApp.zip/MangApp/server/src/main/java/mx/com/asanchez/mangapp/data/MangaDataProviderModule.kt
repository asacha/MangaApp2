package mx.com.asanchez.mangapp.data

import dagger.Binds
import dagger.Module
import mx.com.asanchez.mangapp.data.domain.Provider
import mx.com.asanchez.mangapp.data.providers.MangaProvider
import javax.inject.Singleton

@Module
abstract class MangaDataProviderModule {
    @Binds
    @Singleton
    abstract fun mangaProvider(mangaProvider: MangaDataProvider): MangaProvider
}