package mx.com.asanchez.mangapp.data.mangatown

import dagger.Binds
import dagger.Module
import mx.com.asanchez.mangapp.data.providers.MangaTownProvider
import javax.inject.Singleton

@Module
abstract class MangaTownProviderModule {
    @Binds
    @Singleton
    abstract fun mangaTownProvider(mangaTownProvider: MangaTownDataProvider): MangaTownProvider
}