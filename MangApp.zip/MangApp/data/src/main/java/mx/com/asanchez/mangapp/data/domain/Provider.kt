package mx.com.asanchez.mangapp.data.domain

enum class Provider (
    val mangaProviderId: Int,
    val mangaProviderDescription: String
) {
    MANGATOWN(
        mangaProviderId = 1,
        mangaProviderDescription = "MangaTown"
    )
}