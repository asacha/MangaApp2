package mx.com.asanchez.mangapp.data.providers

import kotlinx.coroutines.Deferred
import mx.com.asanchez.mangapp.data.Result
import mx.com.asanchez.mangapp.data.domain.Manga

interface MangaTownProvider {
    fun fetchLatestMangas(page: Int) : Deferred<Result<List<Manga>>>
    fun fetchMangaDetails(nameLink: String): Deferred<Result<Manga>>
}