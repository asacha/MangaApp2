package mx.com.asanchez.mangapp.mangapp.presentation.mangas.landing

import android.content.Context
import android.databinding.Bindable
import mx.com.asanchez.mangapp.dagger.ACTIVITY_CONTEXT
import mx.com.asanchez.mangapp.dagger.FragmentScope
import mx.com.asanchez.mangapp.data.domain.Manga
import mx.com.asanchez.mangapp.mangapp.BR
import mx.com.asanchez.mangapp.mvp.BaseViewModel
import javax.inject.Inject
import javax.inject.Named

@FragmentScope
class MangasViewModel @Inject constructor(
    @Named(ACTIVITY_CONTEXT) context: Context
) : BaseViewModel(context) {
    var currentIndex: Int = 1

    @get:Bindable
    var availableMangas: List<Manga> = emptyList()
        set(value) {
            field = value
            val tempList = value.map { MangaItemViewModel(context).apply { manga = it } }.toMutableList()
            if (currentIndex == 1) {
                recyclerItemViewModels = tempList
            } else {
                recyclerItemViewModels.addAll(tempList)
            }
            notifyPropertyChanged(BR.availableMangas)
        }

    @Bindable(value = ["availableMangas"])
    var recyclerItemViewModels = mutableListOf<MangaItemViewModel>()
        private set
}
