package mx.com.asanchez.mangapp.mangapp.presentation.mangas.detail

import android.content.Context
import mx.com.asanchez.mangapp.dagger.ACTIVITY_CONTEXT
import mx.com.asanchez.mangapp.dagger.FragmentScope
import mx.com.asanchez.mangapp.mvp.BaseViewModel
import javax.inject.Inject
import javax.inject.Named

@FragmentScope
class MangaDetailsViewModel @Inject constructor(
    @Named(ACTIVITY_CONTEXT) context: Context
) : BaseViewModel(context) {
    var title = "Hola Mundo"
}