package mx.com.asanchez.mangapp.mangapp.presentation.utils

import android.content.Context
import mx.com.asanchez.mangapp.data.domain.Provider

object PreferenceHelper {
    fun getMangaProvider(context: Context): Int =
        context.getSharedPreferences(SP_MANGA_PROVIDER_KEY, Context.MODE_PRIVATE).getInt(
            SP_MANGA_PROVIDER, Provider.MANGATOWN.mangaProviderId
        )

    fun setMangaProvider(context: Context, mangaProviderId: Int) =
        context.getSharedPreferences(SP_MANGA_PROVIDER_KEY, Context.MODE_PRIVATE).edit().putInt(
            SP_MANGA_PROVIDER, mangaProviderId
        ).apply()
}

const val SP_MANGA_PROVIDER_KEY = "sp_provider_key"
const val SP_MANGA_PROVIDER = "sp_provider"
