package mx.com.asanchez.mangapp.mangapp.presentation

import android.os.Bundle
import android.support.v4.app.Fragment
import mx.com.asanchez.mangapp.dagger.BaseDaggerActivity
import mx.com.asanchez.mangapp.data.domain.Manga
import mx.com.asanchez.mangapp.mangapp.R
import mx.com.asanchez.mangapp.mangapp.extensions.commit
import mx.com.asanchez.mangapp.mangapp.presentation.mangas.detail.buildMangaDetailsView
import mx.com.asanchez.mangapp.mangapp.presentation.mangas.landing.MangasView
import javax.inject.Inject

class RootActivity : BaseDaggerActivity(), Navigation {

    @Inject
    lateinit var navigation: Navigation
    private var resumed: Boolean = false
    private var waitingForResumed: () -> Unit = {}
    override var onBackButtonPressed: (() -> Boolean)? = null

    override fun restoreState(savedInstanceState: Bundle?) {
        super.restoreState(savedInstanceState)
        if (savedInstanceState != null) {

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.root_activity_layout)

        navigation.navigateToMangaList()
    }

    //region Navigation
    override fun navigateToMangaList() {
        loadContentFragment(
            fragment = MangasView(),
            tag = Navigation.Screen.MANGA_LIST.tag
        )
    }

    override fun navigateToMandaDetails(manga: Manga) {
        loadContentFragment(
            fragment = buildMangaDetailsView(manga.src!!),
            tag = Navigation.Screen.MANGA_DETAILS.tag
        )
    }
    //endregion

    private fun loadContentFragment(fragment: Fragment, tag: String, addToBackStack: Boolean = true) {
        supportFragmentManager.commit {
            replace(R.id.content, fragment, tag)
            if (addToBackStack) addToBackStack(tag)
        }
    }
}
