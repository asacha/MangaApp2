package mx.com.asanchez.mangapp.mangapp

import dagger.Component
import dagger.android.AndroidInjector
import dagger.android.support.AndroidSupportInjection
import dagger.android.support.AndroidSupportInjectionModule
import mx.com.asanchez.mangapp.data.HttpClientModule
import mx.com.asanchez.mangapp.data.MangaDataProviderModule
import mx.com.asanchez.mangapp.data.mangatown.MangaTownModule
import mx.com.asanchez.mangapp.data.mangatown.MangaTownProviderModule
import mx.com.asanchez.mangapp.mangapp.presentation.MangaProviderModule
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        AndroidSupportInjectionModule::class,
        TimberTreeModule::class,
        AppModule::class,
        ActivitiesBuilderModule::class,

        HttpClientModule::class,

        MangaProviderModule::class,
        MangaDataProviderModule::class,

        MangaTownModule::class,
        MangaTownProviderModule::class
    ]
)
interface AppComponent : AndroidInjector<MangaAppApplication> {
    @Component.Builder
    abstract class Builder : AndroidInjector.Builder<MangaAppApplication>()
}