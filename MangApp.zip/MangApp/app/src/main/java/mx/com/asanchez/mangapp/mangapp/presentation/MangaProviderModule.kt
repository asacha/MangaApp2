package mx.com.asanchez.mangapp.mangapp.presentation

import android.content.Context
import dagger.Module
import dagger.Provides
import mx.com.asanchez.mangapp.dagger.APPLICATION_CONTEXT
import mx.com.asanchez.mangapp.data.domain.Provider
import mx.com.asanchez.mangapp.mangapp.presentation.utils.PreferenceHelper
import javax.inject.Named
import javax.inject.Singleton

@Module
object MangaProviderModule {
    @JvmStatic
    @Singleton
    @Provides
    fun mangaProvider(@Named(APPLICATION_CONTEXT) app: Context) =
        when (PreferenceHelper.getMangaProvider(app)) {
            Provider.MANGATOWN.mangaProviderId -> Provider.MANGATOWN
            else -> Provider.MANGATOWN
        }
}