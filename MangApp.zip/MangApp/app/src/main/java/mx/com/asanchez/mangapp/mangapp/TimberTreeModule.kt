package mx.com.asanchez.mangapp.mangapp

import dagger.Module
import dagger.Provides
import timber.log.Timber.Tree
import timber.log.Timber.DebugTree

@Module
class TimberTreeModule {
    @Provides
    fun timberTree(): Tree = DebugTree()
}