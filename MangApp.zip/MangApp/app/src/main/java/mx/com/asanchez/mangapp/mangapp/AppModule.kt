package mx.com.asanchez.mangapp.mangapp

import android.app.Application
import android.content.Context
import dagger.Module
import dagger.Provides
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import mx.com.asanchez.mangapp.dagger.APPLICATION_CONTEXT
import javax.inject.Named
import javax.inject.Singleton

@Module
internal class AppModule {
    @Provides
    @Singleton
    fun application(app: MangaAppApplication): Application = app

    @Provides
    @Singleton
    @Named(APPLICATION_CONTEXT)
    fun applicationContext(app: Application): Context = app.applicationContext

    @Provides
    @Singleton
    fun mainDispatcher(): CoroutineDispatcher = Dispatchers.Main
}