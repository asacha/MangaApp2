package mx.com.asanchez.mangapp.mangapp

import dagger.Module
import dagger.android.ContributesAndroidInjector
import mx.com.asanchez.mangapp.dagger.ActivityScope
import mx.com.asanchez.mangapp.mangapp.presentation.RootActivity
import mx.com.asanchez.mangapp.mangapp.presentation.RootActivityModule

@Module
internal abstract class ActivitiesBuilderModule {
    @ActivityScope
    @ContributesAndroidInjector(modules = [RootActivityModule::class])
    internal abstract fun rootActivity(): RootActivity
}