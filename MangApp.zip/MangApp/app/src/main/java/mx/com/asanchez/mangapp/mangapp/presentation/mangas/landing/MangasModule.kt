package mx.com.asanchez.mangapp.mangapp.presentation.mangas.landing

import dagger.Module
import mx.com.asanchez.mangapp.dagger.BaseFragmentModule

@Module
abstract class MangasModule : BaseFragmentModule<MangasView>()