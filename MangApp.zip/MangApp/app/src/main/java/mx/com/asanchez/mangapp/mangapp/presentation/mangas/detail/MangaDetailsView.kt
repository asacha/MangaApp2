package mx.com.asanchez.mangapp.mangapp.presentation.mangas.detail


import android.view.LayoutInflater
import android.view.ViewGroup
import mx.com.asanchez.mangapp.mangapp.databinding.MangaDetailsLayoutBinding
import mx.com.asanchez.mangapp.mvp.BaseMvpFragment
import timber.log.Timber

class MangaDetailsView : BaseMvpFragment<MangaDetailsPresenter, MangaDetailsViewModel, MangaDetailsLayoutBinding>() {

    override fun inflateDataBinding(inflater: LayoutInflater, container: ViewGroup?): MangaDetailsLayoutBinding =
        MangaDetailsLayoutBinding.inflate(layoutInflater, container, false).also { layout ->
            Timber.d("MangaDetailsView_TAG: inflateDataBinding")
            layout.tvTest.text = "Test 1"
        }
}
