package mx.com.asanchez.mangapp.mangapp.presentation.mangas.landing

import android.databinding.DataBindingUtil
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import mx.com.asanchez.mangapp.dagger.FragmentScope
import mx.com.asanchez.mangapp.data.domain.Manga
import mx.com.asanchez.mangapp.mangapp.R
import mx.com.asanchez.mangapp.mangapp.databinding.MangaItemLayoutBinding
import timber.log.Timber

@FragmentScope
class MangasAdapter(
    private val listener: (Manga) -> Unit
) : RecyclerView.Adapter<MangasAdapter.ViewHolder>() {
    var itemsList: List<MangaItemViewModel> = emptyList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    inner class ViewHolder(val itemBinding: MangaItemLayoutBinding) : RecyclerView.ViewHolder(itemBinding.root) {

        fun bind(manga: Manga, clickListener: (Manga) -> Unit) {
            itemView.setOnClickListener { clickListener(manga) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder =
        DataBindingUtil.inflate<MangaItemLayoutBinding>(
            LayoutInflater.from(parent.context), R.layout.manga_item_layout, parent, false
        ).run {
            ViewHolder(this)
        }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemBinding.viewModel = itemsList[position]
        holder.bind(itemsList[position].manga!!, listener)

        holder.itemBinding.executePendingBindings()
    }

    override fun getItemCount(): Int = itemsList.size
}