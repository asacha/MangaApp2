package mx.com.asanchez.mangapp.mangapp.extensions

import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentTransaction

inline fun FragmentManager.commit(block: FragmentTransaction.() -> Unit) {
    beginTransaction().run {
        block(this)
        commit()
    }
}