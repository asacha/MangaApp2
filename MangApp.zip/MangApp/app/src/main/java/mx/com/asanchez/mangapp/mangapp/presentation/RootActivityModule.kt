package mx.com.asanchez.mangapp.mangapp.presentation

import dagger.Binds
import dagger.Module
import mx.com.asanchez.mangapp.dagger.ActivityScope
import mx.com.asanchez.mangapp.dagger.BaseActivityModule

@Module(includes = [FragmentBuilderModule::class])
abstract class RootActivityModule : BaseActivityModule<RootActivity>() {
    @Binds
    @ActivityScope
    abstract fun navigation(activity: RootActivity): Navigation
}