package mx.com.asanchez.mangapp.mangapp.presentation.mangas.detail

import mx.com.asanchez.mangapp.dagger.FragmentScope
import mx.com.asanchez.mangapp.mvp.BasePresenter
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Named

@FragmentScope
class MangaDetailsPresenter @Inject constructor(
    viewModel: MangaDetailsViewModel,
    @Named(MANGA_SRC) private val mangaSrc: String
) : BasePresenter<MangaDetailsViewModel>(viewModel) {
    override fun start() {
        super.start()
        Timber.d("MangaDetailsPresenter_TAG: start: mangaSrc: $mangaSrc")
    }
}