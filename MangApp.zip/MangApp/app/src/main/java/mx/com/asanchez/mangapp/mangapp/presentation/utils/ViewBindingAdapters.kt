package mx.com.asanchez.mangapp.mangapp.presentation.utils

import android.databinding.BindingAdapter
import android.widget.ImageView
import com.squareup.picasso.Picasso
import timber.log.Timber

@BindingAdapter(value = ["imageUrl", "placeHolder"], requireAll = false)
fun imageUrl(view: ImageView, imageUrl: String?, placeholder: Int = 0) {
    if (imageUrl.isNullOrEmpty()) {
        Timber.d("_TAG: imageUrl: no image available")
        view.setImageDrawable(null)
        return
    }
    when(placeholder) {
        0 -> {
            Picasso.get().load(imageUrl).into(view)
        }
        else -> {
            Picasso.get().load(imageUrl).placeholder(placeholder)
        }
    }
}