package mx.com.asanchez.mangapp.mangapp.presentation.mangas.detail

import android.os.Bundle
import android.support.v4.app.Fragment
import dagger.Module
import dagger.Provides
import mx.com.asanchez.mangapp.dagger.BaseFragmentModule
import mx.com.asanchez.mangapp.dagger.FragmentScope
import javax.inject.Named

@Module(includes = [MangaDetailsParamsModule::class])
abstract class MangaDetailsModule : BaseFragmentModule<MangaDetailsView>()

@Module
object MangaDetailsParamsModule {
    @JvmStatic
    @Provides
    @Named(MANGA_SRC)
    @FragmentScope
    fun mangaSrc(view: Fragment): String = view.arguments?.getString(MANGA_SRC)!!
}

fun buildMangaDetailsView(mangaSrc: String) = MangaDetailsView().apply {
    arguments = Bundle().apply {
        putString(MANGA_SRC, mangaSrc)
    }
}

const val MANGA_SRC = "manga-details.manga-src"