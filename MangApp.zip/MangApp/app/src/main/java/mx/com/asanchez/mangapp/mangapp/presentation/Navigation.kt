package mx.com.asanchez.mangapp.mangapp.presentation

import mx.com.asanchez.mangapp.data.domain.Manga

interface Navigation {
    var onBackButtonPressed: (() -> Boolean)?

    fun navigateToMangaList()
    fun navigateToMandaDetails(manga: Manga)

    enum class Screen(val tag: String) {
        MANGA_LIST("manga_list"),
        MANGA_DETAILS("manga_details")
        ;

        companion object {
            fun fromTag(tag: String?) = values().find { it.tag == tag }
        }
    }
}