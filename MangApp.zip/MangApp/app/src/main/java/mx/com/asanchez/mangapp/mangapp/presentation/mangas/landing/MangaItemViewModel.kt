package mx.com.asanchez.mangapp.mangapp.presentation.mangas.landing

import android.content.Context
import mx.com.asanchez.mangapp.data.domain.Manga
import mx.com.asanchez.mangapp.mvp.BaseViewModel

class MangaItemViewModel(
    context: Context
) : BaseViewModel(context) {
    var manga: Manga? = null
        set(value) {
            field = value
            notifyChange()
        }

    var title: String? = null
        get() = manga?.title

    var coverUrl: String? = null
        get() = manga?.coverUrl

    var latestChapter: String? = null
        get() = manga?.latestChapter
}