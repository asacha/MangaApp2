package mx.com.asanchez.mangapp.mangapp.presentation

import dagger.Module
import dagger.android.ContributesAndroidInjector
import mx.com.asanchez.mangapp.dagger.FragmentScope
import mx.com.asanchez.mangapp.mangapp.presentation.mangas.detail.MangaDetailsModule
import mx.com.asanchez.mangapp.mangapp.presentation.mangas.detail.MangaDetailsView
import mx.com.asanchez.mangapp.mangapp.presentation.mangas.landing.MangasModule
import mx.com.asanchez.mangapp.mangapp.presentation.mangas.landing.MangasView

@Module
internal abstract class FragmentBuilderModule {
    @FragmentScope
    @ContributesAndroidInjector(modules = [MangasModule::class])
    internal abstract fun mangasView(): MangasView

    @FragmentScope
    @ContributesAndroidInjector(modules = [MangaDetailsModule::class])
    internal abstract fun mangaDetailsView(): MangaDetailsView
}