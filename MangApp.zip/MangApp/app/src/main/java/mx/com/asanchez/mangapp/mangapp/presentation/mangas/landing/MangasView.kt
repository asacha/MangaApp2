package mx.com.asanchez.mangapp.mangapp.presentation.mangas.landing

import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import mx.com.asanchez.mangapp.mangapp.BR
import mx.com.asanchez.mangapp.mangapp.databinding.MangasLandingLayoutBinding
import mx.com.asanchez.mangapp.mvp.BaseMvpFragment

class MangasView : BaseMvpFragment<MangasPresenter, MangasViewModel, MangasLandingLayoutBinding>() {

    private lateinit var adapter: MangasAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //region initialize variables
        adapter.itemsList = viewModel.recyclerItemViewModels
        //endregion

        //region wire up properties
        binding?.swipeRefresh?.setOnRefreshListener {
            presenter.onViewRefreshed()
        }

        binding?.rvMangas?.setOnScrollChangeListener { _, _, _, _, _ ->
            if (!binding?.rvMangas?.canScrollVertically(1)!!) {
                presenter.onEndOfScroll()
            }
        }

        viewModel.onPropertyChanged(BR.availableMangas) {
            binding?.swipeRefresh?.isRefreshing = false
            adapter.itemsList = viewModel.recyclerItemViewModels
        }
        //endregion
    }

    override fun inflateDataBinding(inflater: LayoutInflater, container: ViewGroup?): MangasLandingLayoutBinding =
        MangasLandingLayoutBinding.inflate(layoutInflater, container, false).also { layout ->
            adapter = MangasAdapter { manga -> presenter.onMangaClicked(manga) }

            layout.rvMangas.layoutManager = GridLayoutManager(activity?.applicationContext!!, 3)
            layout.rvMangas.adapter = adapter
        }
}