package mx.com.asanchez.mangapp.mangapp.presentation.mangas.landing

import mx.com.asanchez.mangapp.dagger.FragmentScope
import mx.com.asanchez.mangapp.data.Result
import mx.com.asanchez.mangapp.data.domain.Manga
import mx.com.asanchez.mangapp.data.providers.MangaProvider
import mx.com.asanchez.mangapp.mangapp.extensions.runOnResult
import mx.com.asanchez.mangapp.mangapp.presentation.Navigation
import mx.com.asanchez.mangapp.mvp.BasePresenter
import javax.inject.Inject

@FragmentScope
class MangasPresenter @Inject constructor(
    viewModel: MangasViewModel,
    private val navigation: Navigation,
    private val mangaProvider: MangaProvider
) : BasePresenter<MangasViewModel>(viewModel) {

    //region Events
    override fun start() {
        super.start()
        fetchMangas()
    }

    fun onViewRefreshed() {
        viewModel.currentIndex = 1
        fetchMangas()
    }

    fun onMangaClicked(manga: Manga) {
        navigation.navigateToMandaDetails(manga)
    }

    fun onEndOfScroll() {
        viewModel.currentIndex++
        fetchMangas()
    }
    //endregion

    //region Methods
    private fun fetchMangas(): Unit = background {
        //Get list of mangas
        mangaProvider.fetchLatestMangas(viewModel.currentIndex).runOnResult {
            when (this) {
                is Result.Err -> error.printStackTrace()
                is Result.Ok -> viewModel.availableMangas = result
            }
        }
    }
    //endregion
}