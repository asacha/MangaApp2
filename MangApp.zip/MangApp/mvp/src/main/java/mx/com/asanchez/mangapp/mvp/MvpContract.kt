package mx.com.asanchez.mangapp.mvp

import android.databinding.Observable

interface MvpPresenter {
    fun start()
    fun resume()
    fun pause()
    fun stop()
}

interface MvpViewModel : Observable {
    fun onPropertyChanged(propertyId: Int, action: () -> Unit)
}